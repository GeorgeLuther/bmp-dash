import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
} from "@mui/material";
import { usePersonnel } from "@/contexts/PersonnelContext";
import { useReleaseTableViews } from "../hooks/useReleaseTableViews";

type Props = {
  open: boolean;
  onClose: () => void;
  tableState: any;
};

export default function ReleaseSaveViewDialog({
  open,
  onClose,
  tableState,
}: Props) {
  const { personnel } = usePersonnel();
  const userId: string | null = personnel?.id ?? null;
  const { saveView } = useReleaseTableViews(userId);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  useEffect(() => {
    if (open) {
      setName("");
      setDescription("");
    }
  }, [open]);

  const handleSave = async () => {
    if (!name.trim()) return;
    await saveView({
      user_id: userId,
      name: name.trim(),
      description: description.trim(),
      filters: tableState.columnFilters ?? [],
      sorting: tableState.sorting ?? [],
      column_visibility: tableState.columnVisibility ?? {},
      column_order: tableState.columnOrder ?? [],
      grouping: tableState.grouping ?? [],
      density: tableState.density ?? "comfortable",
    });
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth>
      <DialogTitle>Save Current View</DialogTitle>
      <DialogContent>
        <TextField
          label="View Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          autoFocus
          required
          fullWidth
          margin="normal"
        />
        <TextField
          label="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          fullWidth
          margin="normal"
          multiline
          minRows={2}
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          onClick={handleSave}
          variant="contained"
          disabled={!name.trim()}
        >
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
}
