import React, { useState } from "react";
import {
  MaterialReactTable,
  MRT_ActionMenuItem,
  useMaterialReactTable,
  MRT_ToolbarInternalButtons,
  type MRT_Row,
} from "material-react-table";

import { IconButton, Menu, MenuItem } from "@mui/material";

import ViewListIcon from "@mui/icons-material/ViewList";
import SaveIcon from "@mui/icons-material/Save";
import { Edit, Delete } from "@mui/icons-material";

import RightDrawer from "./ReleaseDrawer";
import SaveViewDialog from "./SaveViewDialog";

import { Release } from "../../../types/Release";
import { releaseColumns } from "./ReleaseTable.columns";
import { useReleases } from "@/hooks/getAllReleases";
import { useReleaseTableViews } from "@/hooks/useReleaseTableViews";

const ReleasesTable = () => {
  const { data: releaseData, isLoading, error } = useReleases();
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState<Release | null>(null);

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [savedViews, setSavedViews] = useState<any[]>([]);
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);

  const { fetchVisibleViews } = useReleaseTableViews();
  const open = Boolean(anchorEl);

  const handleMenuClick = async (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
    const views = await fetchVisibleViews();
    setSavedViews(views);
  };

  const handleMenuClose = () => setAnchorEl(null);

  const tableInstance = useMaterialReactTable({
    columns: releaseColumns,
    data: releaseData ?? [],
    enableGrouping: true,
    initialState: {
      grouping: ["week_projected"],
    },
    enableRowActions: true,
    muiTablePaperProps: {
      sx: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        width: "100%",
      },
    },
    muiTableContainerProps: {
      sx: {
        flex: 1,
        minHeight: 0,
      },
    },
    renderToolbarInternalActions: ({ table }) => (
      <>
        <IconButton onClick={handleMenuClick} title="View Presets">
          <ViewListIcon />
        </IconButton>
        <IconButton
          onClick={() => setSaveDialogOpen(true)}
          title="Save Current View"
        >
          <SaveIcon />
        </IconButton>
        <MRT_ToolbarInternalButtons table={table} />
        <Menu anchorEl={anchorEl} open={open} onClose={handleMenuClose}>
          {savedViews.map((view) => (
            <MenuItem
              key={view.id}
              onClick={() => {
                table.setColumnFilters(view.filters);
                table.setSorting(view.sorting);
                table.setColumnVisibility(view.column_visibil);
                table.setColumnOrder(view.column_order);
                handleMenuClose();
              }}
            >
              {view.name}
            </MenuItem>
          ))}
        </Menu>
      </>
    ),
    renderRowActionMenuItems: ({ row, table, closeMenu }) => [
      <MRT_ActionMenuItem
        icon={<Edit />}
        key="edit"
        label="Edit"
        onClick={() => {
          setSelectedRowData(row.original);
          setIsDrawerOpen(true);
          closeMenu();
        }}
        table={table}
      />,
      <MRT_ActionMenuItem
        icon={<Delete />}
        key="delete"
        label="Delete"
        onClick={() => {
          console.info("Delete", row.original);
          closeMenu();
        }}
        table={table}
      />,
    ],
  });

  return (
    <>
      <MaterialReactTable table={tableInstance} />

      {selectedRowData && (
        <RightDrawer
          open={isDrawerOpen}
          onClose={() => setIsDrawerOpen(false)}
          rowData={selectedRowData}
        />
      )}

      <SaveViewDialog
        open={saveDialogOpen}
        onClose={() => setSaveDialogOpen(false)}
        table={tableInstance}
      />
    </>
  );
};

export default ReleasesTable;
