import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControlLabel,
  Checkbox,
  Button,
} from "@mui/material";

import { useReleaseTableViews } from "@/hooks/useReleaseTableViews";

interface SaveViewDialogProps {
  open: boolean;
  onClose: () => void;
  table: any; // You can replace this with a proper MRT_TableInstance<Release> if needed
}

const SaveViewDialog: React.FC<SaveViewDialogProps> = ({
  open,
  onClose,
  table,
}) => {
  const { saveView } = useReleaseTableViews();
  const [viewName, setViewName] = useState("");
  const [isShared, setIsShared] = useState(true);

  const handleSave = async () => {
    const state = table.getState();
    const config = {
      filters: state.columnFilters,
      sorting: state.sorting,
      column_visibil: state.columnVisibility,
      column_order: state.columnOrder,
    };

    await saveView(viewName, config, { isShared });
    setViewName("");
    setIsShared(true);
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>Save View Preset</DialogTitle>
      <DialogContent>
        <TextField
          autoFocus
          fullWidth
          margin="dense"
          label="Preset Name"
          value={viewName}
          onChange={(e) => setViewName(e.target.value)}
        />
        <FormControlLabel
          control={
            <Checkbox
              checked={isShared}
              onChange={(e) => setIsShared(e.target.checked)}
            />
          }
          label="Share with everyone"
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          onClick={handleSave}
          disabled={!viewName.trim()}
          variant="contained"
        >
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default SaveViewDialog;
