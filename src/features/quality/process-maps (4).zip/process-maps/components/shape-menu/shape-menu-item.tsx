import { useRef } from "react";
import Shape from "../shape";
import { getShapeById, type ShapeType } from "../shape/types";

type Props = { type: ShapeType };

export default function ShapeMenuItem({ type }: Props) {
  const def = getShapeById(type);
  if (!def) return null;

  // simple preview sizing based on gridAspect
  const { cols, rows } = def.meta.gridAspect;
  const previewWidth = 112;
  const previewHeight = Math.round(previewWidth * (rows / cols));

  // use a custom drag image so the ghost matches the shape
  const dragImgRef = useRef<HTMLDivElement>(null);

  const onDragStart: React.DragEventHandler<HTMLDivElement> = (e) => {
    e.dataTransfer.setData("application/reactflow", type);
    e.dataTransfer.effectAllowed = "move";
    if (dragImgRef.current) {
      e.dataTransfer.setDragImage(dragImgRef.current, 0, 0);
    }
  };

  return (
    <div draggable onDragStart={onDragStart}>
      {/* hidden drag image */}
      <div
        ref={dragImgRef}
        style={{ position: "absolute", opacity: 0, pointerEvents: "none" }}
      >
        <Shape type={type} width={previewWidth} height={previewHeight} />
      </div>

      {/* visible preview */}
      <div style={{ width: previewWidth, height: previewHeight }}>
        <Shape type={type} width={previewWidth} height={previewHeight} />
      </div>

      {/* label */}
      <div>{def.meta.label}</div>
    </div>
  );
}
