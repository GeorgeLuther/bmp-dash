export type ReleaseTableView = {
  id: string;
  user_id: string | null;
  name: string;
  description?: string | null;
  is_default?: boolean;
  is_shared?: boolean;
  shared_with_roles?: string[];
  filters?: any;
  sorting?: any;
  column_visibility?: Record<string, boolean>;
  column_order?: string[];
  grouping?: string[];
  created_at?: string;
  updated_at?: string;
};
