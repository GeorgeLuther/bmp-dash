import { useState } from "react";
import { supabase } from "@/supabase/client";

export interface ReleaseTableViewConfig {
  filters: any;
  sorting: any;
  column_visibil: Record<string, boolean>;
  column_order: string[];
}

export function useReleaseTableViews() {
  const [loading, setLoading] = useState(false);

  const saveView = async (
    name: string,
    config: ReleaseTableViewConfig,
    options?: { isShared?: boolean }
  ) => {
    setLoading(true);

    const { data: userData, error: userError } = await supabase.auth.getUser();
    const user_id = userData?.user?.id;

    const { error } = await supabase.from("release_table_views").insert({
      user_id,
      name,
      filters: config.filters,
      sorting: config.sorting,
      column_visibil: config.column_visibil,
      column_order: config.column_order,
      is_shared: options?.isShared ?? false,
    });

    if (error) console.error("Failed to save view:", error.message);
    setLoading(false);
  };

  const fetchVisibleViews = async () => {
    const { data: userData } = await supabase.auth.getUser();
    const user_id = userData?.user?.id;

    const { data, error } = await supabase
      .from("release_table_views")
      .select("*")
      .or(`is_shared.eq.true,user_id.eq.${user_id}`);

    if (error) {
      console.error("Failed to fetch views:", error.message);
      return [];
    }

    return data;
  };

  return {
    saveView,
    fetchVisibleViews,
    loading,
  };
}
