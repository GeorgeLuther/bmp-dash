import * as React from "react";
import * as ReactDOM from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router";

import App from "./App";
import Layout from "./layouts/dashboard";
import SignInPage from "./pages/signin";

// Pages
import AllReleasesPage from "./features/scheduling/pages";
import AccountPage from "./features/account/Pages/account";
import WIPPage from "./pages/WIPPage"; // placeholder until real pages exist

// IMPORTANT: child paths below MUST match the NAVIGATION "segment" values in App.tsx
const router = createBrowserRouter([
  {
    element: <App />,
    children: [
      {
        path: "/",
        element: <Layout />,
        children: [
          // Landing page
          { index: true, element: <AllReleasesPage /> },

          // Scheduling
          { path: "all_releases", element: <AllReleasesPage /> },

          // Quality (segments match NAV segments)
          { path: "process_maps", element: <WIPPage /> },
          { path: "internal_audits", element: <WIPPage /> },
          { path: "management_reviews", element: <WIPPage /> },
          { path: "calibration", element: <WIPPage /> },

          // Training
          { path: "training_events", element: <WIPPage /> },
          { path: "personnel", element: <WIPPage /> },

          // Account
          { path: "account", element: <AccountPage /> },
        ],
      },
      // Auth
      { path: "/sign-in", element: <SignInPage /> },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
