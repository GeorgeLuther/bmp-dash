// src/navigation.ts

import {
  CalendarMonth,
  TableChart,
  Verified,
  SchemaOutlined,
  ContentPasteSearch,
  AssignmentTurnedInOutlined,
  Straighten,
  School,
  Event,
  Groups,
  AccountBox,
} from "@mui/icons-material";

import AllReleasesPage from "./features/scheduling/pages";
import AccountPage from "./features/account/Pages/account";
import WIPPage from "./pages/WIPPage";
//import ProcessMapsPage from "./features/quality/pages/ProcessMapsPage"; // TODO build out process map studio
// import InternalAuditsPage from "./features/quality/pages/InternalAuditsPage"; // TODO make filler page, plan implementation & demo
// import ManagementReviewsPage from "./features/quality/pages/ManagementReviewsPage"; // TODO make filler page, plan implementation & demo
// import CalibrationPage from "./features/quality/pages/CalibrationPage"; // TODO make filler page, plan implementation & demo
// import TrainingEventsPage from "./features/training/pages/TrainingEventsPage"; // TODO make filler page, plan implementation & demo
// import PersonnelPage from "./features/training/pages/PersonnelPage"; // TODO pull personnel, fix account view and make personnel detail

export const NAVIGATION_ITEMS = [
  { kind: "header", title: "Main items" },
  {
    title: "Scheduling",
    icon: <CalendarMonth />,
    children: [
      {
        path: "/scheduling/all_releases",
        title: "All Releases",
        icon: <TableChart />,
        component: AllReleasesPage,
      },
    ],
  },
  {
    title: "Quality",
    icon: <Verified />,
    children: [
      {
        path: "/quality/process_maps",
        title: "Process Maps",
        icon: <SchemaOutlined />,
        component: WIPPage,
        //component: ProcessMapsPage,
      },
      {
        path: "/quality/internal_audits",
        title: "Internal Audits",
        icon: <ContentPasteSearch />,
        component: WIPPage,
        //component: InternalAuditsPage,
      },
      {
        path: "/quality/management_reviews",
        title: "Management Reviews",
        icon: <AssignmentTurnedInOutlined />,
        component: WIPPage,
        //component: ManagementReviewsPage,
      },
      {
        path: "/quality/calibration",
        title: "Calibration",
        icon: <Straighten />,
        component: WIPPage,
        //component: CalibrationPage,
      },
    ],
  },
  {
    title: "Training",
    icon: <School />,
    children: [
      {
        path: "/training/events",
        title: "Events",
        icon: <Event />,
        component: WIPPage,
        //component: TrainingEventsPage,
      },
      {
        path: "/training/personnel",
        title: "Personnel",
        icon: <Groups />,
        component: WIPPage,
        //component: PersonnelPage,
      },
    ],
  },
  {
    path: "/account",
    title: "Account",
    icon: <AccountBox />,
    component: AccountPage,
  },
];
