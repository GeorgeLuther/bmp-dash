import React, { useState } from "react";
import {
  MaterialReactTable,
  MRT_ActionMenuItem,
  useMaterialReactTable,
  type MRT_Row,
} from "material-react-table";

import { IconButton, Menu, MenuItem } from "@mui/material";
import ViewListIcon from "@mui/icons-material/ViewList";
import { Edit, Delete } from "@mui/icons-material";

import RightDrawer from "./ReleaseDrawer";
import { Release } from "../../../types/Release";
import { releaseColumns } from "./ReleaseTable.columns";
import { useReleases } from "@/hooks/getAllReleases";
import { useReleaseTableViews } from "@/hooks/useReleaseTableViews";

const ReleasesTable = () => {
  const { data: releaseData, isLoading, error } = useReleases();
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState<Release | null>(null);

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [savedViews, setSavedViews] = useState<any[]>([]);
  const { fetchVisibleViews } = useReleaseTableViews();
  const open = Boolean(anchorEl);

  const handleMenuClick = async (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
    const views = await fetchVisibleViews();
    setSavedViews(views);
  };

  const handleMenuClose = () => setAnchorEl(null);

  const applyView = (view: any) => {
    tableInstance.setColumnFilters(view.filters);
    tableInstance.setSorting(view.sorting);
    tableInstance.setColumnVisibility(view.column_visibil);
    tableInstance.setColumnOrder(view.column_order);
    handleMenuClose();
  };

  const tableInstance = useMaterialReactTable({
    columns: releaseColumns,
    data: releaseData ?? [],
    enableGrouping: true,
    initialState: {
      grouping: ["week_projected"],
    },
    enableRowActions: true,
    muiTablePaperProps: {
      sx: {
        display: "flex",
        flexDirection: "column",
        height: "97%",
        width: "100%",
      },
    },
    muiTableContainerProps: {
      sx: {
        flex: 1,
        minHeight: 0,
      },
    },
    renderToolbarInternalActions: ({ table }) => {
      return (
        <>
          {/* 🚨 Your custom icon button */}
          <IconButton onClick={handleMenuClick} title="View Presets">
            <ViewListIcon />
          </IconButton>

          {/* 📋 The view selection menu */}
          <Menu anchorEl={anchorEl} open={open} onClose={handleMenuClose}>
            {savedViews.map((view) => (
              <MenuItem key={view.id} onClick={() => applyView(view)}>
                {view.name}
              </MenuItem>
            ))}
          </Menu>
        </>
      );
    },
    renderRowActionMenuItems: ({ row, table, closeMenu }) => [
      <MRT_ActionMenuItem
        icon={<Edit />}
        key="edit"
        label="Edit"
        onClick={() => {
          setSelectedRowData(row.original);
          setIsDrawerOpen(true);
          closeMenu();
        }}
        table={table}
      />,
      <MRT_ActionMenuItem
        icon={<Delete />}
        key="delete"
        label="Delete"
        onClick={() => {
          console.info("Delete", row.original);
          closeMenu();
        }}
        table={table}
      />,
    ],
  });

  return (
    <>
      <MaterialReactTable table={tableInstance} />

      {selectedRowData && (
        <RightDrawer
          open={isDrawerOpen}
          onClose={() => setIsDrawerOpen(false)}
          rowData={selectedRowData}
        />
      )}
    </>
  );
};

export default ReleasesTable;
