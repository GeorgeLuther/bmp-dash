import { useEffect, useState } from "react";
import { ReleaseTableView } from "@/features/scheduling/releaseTable/types/releaseTableView.types";
import { saveReleaseTableView } from "@/features/scheduling/releaseTable/services/releaseViewService";
import { supabase } from "@/supabase/client";

export function useReleaseTableViews(userId: string | null) {
  const [views, setViews] = useState<ReleaseTableView[]>([]);

  useEffect(() => {
    if (!userId) return;

    supabase
      .from("release_table_views")
      .select("*")
      .or(`is_shared.eq.true,user_id.eq.${userId}`)
      .order("name")
      .then(({ data, error }) => {
        if (error) console.error("Failed to fetch views:", error);
        if (data) setViews(data);
      });
  }, [userId]);

  const saveView = async (view: Partial<ReleaseTableView>) => {
    const saved = await saveReleaseTableView(view);
    if (saved) setViews((prev) => [...prev, saved]);
  };

  return { views, saveView };
}
