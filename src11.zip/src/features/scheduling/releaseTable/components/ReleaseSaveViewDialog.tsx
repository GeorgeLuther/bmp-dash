import { IconButton, Tooltip } from "@mui/material";
import SaveIcon from "@mui/icons-material/Save";
import { useSessionContext } from "@/contexts/SessionContext"; // update path if needed
import { useReleaseTableViews } from "../hooks/useReleaseTableViews";

export default function ReleaseSaveViewButton({ table }) {
  const { user } = useSessionContext();
  const { saveView } = useReleaseTableViews(user?.id);

  const handleSave = () => {
    const name = prompt("Name this view:");
    if (!name) return;

    const state = table.getState();

    saveView({
      user_id: user?.id,
      name,
      filters: state.columnFilters,
      sorting: state.sorting,
      column_visibility: state.columnVisibility,
      column_order: state.columnOrder,
      grouping: state.grouping,
    });
  };

  return (
    <Tooltip title="Save current view">
      <IconButton onClick={handleSave}>
        <SaveIcon />
      </IconButton>
    </Tooltip>
  );
}
