import * as React from "react";
import Typography from "@mui/material/Typography";

export default function WeldPage() {
  return (
    <Typography>Welder's Schedule w/ KPIs at top? will show here</Typography>
  );
}
