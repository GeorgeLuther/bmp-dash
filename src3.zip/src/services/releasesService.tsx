
import { supabase } from "../supabase/client";
import type { Release } from "../types/Release";

export async function fetchReleases(): Promise<Release[]> {
  const { data, error } = await supabase
    .from<Release>("releases")
    .select()